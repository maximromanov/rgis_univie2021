######################################################################################################
# PART I :: LIBRARIES & DATA #########################################################################
######################################################################################################

library(shiny)
library(tidyverse)
library(readr)
library(stringr)
library(ggplot2)
library(igraph)
library(ggrepel)

# LOAD AND PREPARE DATA

ubahnEdges <- read_delim("wien_ubahn.csv", ",", escape_double = FALSE, trim_ws = TRUE)
ubahnNodes <- read_delim("wien_ubahn_nodes.csv", ",", escape_double = FALSE, trim_ws = TRUE)

stations <- ubahnNodes$STATION # for the drop down list of stations

ubahnEdgesPlot <- ubahnEdges %>%
  rename(EDGELINE = LINE) %>%
  left_join(ubahnNodes, by = c("FROM"="STATION")) %>% rename(XFROM = XVAL, YFROM = YVAL) %>%
  left_join(ubahnNodes, by = c("TO"="STATION")) %>% rename(XTO = XVAL, YTO = YVAL)

ubahnNodesPlot <- ubahnNodes
ubahnNetwork <- graph_from_data_frame(d=ubahnEdges, vertices=ubahnNodes, directed=FALSE)

######################################################################################################
# PART II :: FUNCTION THAT CALCULATES THE PATH AND GRAPHS IT  ########################################
######################################################################################################

subwayPath <- function(departure, arrival){

  shortest_path <- shortest_paths(ubahnNetwork, from = departure, to = arrival)$vpath
  shortest_path <- names(unlist(shortest_path))
  shortest_path <- tibble(ID = shortest_path) %>%
    left_join(ubahnNodes, by = c("ID" = "STATION"))
  
  ggplot() +
    geom_segment(data=ubahnEdgesPlot, aes(x=XFROM, y=YFROM, xend=XTO, yend=YTO), color="grey", lwd=3) +
    geom_path(data = shortest_path, aes(x=XVAL, y=YVAL), col="red", lwd=4) + 
    geom_point(data=ubahnNodesPlot, aes(x=XVAL, y=YVAL), color="black", size=3) +
    geom_point(data=ubahnNodesPlot, aes(x=XVAL, y=YVAL), color="white", size=2) +
    geom_text_repel(data=ubahnNodesPlot, aes(x=XVAL, y=YVAL, label=STATION), color="black", size=2, max.overlaps=100) +
    theme_void() +
    theme(legend.position = "none")
}

######################################################################################################
# PART III :: THE APP ITSELF  ########################################################################
######################################################################################################

# Define UI ----
ui <- fluidPage(
  titlePanel("Vienna Subway"),
  textOutput("itinerary"), # output$itinerary
  plotOutput("shortestPath", width="100%"), # output$shortestPath

  fluidRow(
    column(width = 3, selectInput("from_station", "From", stations)),
    column(width = 3, selectInput("to_station", "To", stations))
  )
)

# Define server logic ----
server <- function(input, output) {
  output$itinerary <- renderText({paste0("Traveling from ", input$from_station, " to ", input$to_station)})
  output$shortestPath <- renderPlot({subwayPath(input$from_station, input$to_station)})
}

# Run the app ----
shinyApp(ui = ui, server = server)
